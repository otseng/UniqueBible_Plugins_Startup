# Use the plugin menu/Toggle Verse Reference to toggle the verse numbers

import config, re

def toggleVerseReference(text):
    if not hasattr(config, "displayVerseReference"):
        config.displayVerseReference = True
    if not config.displayVerseReference:
        text = re.sub('<vid .*?>.*?</vid>', '', text)
    return text


config.bibleWindowContentTransformers.append(toggleVerseReference)
config.studyWindowContentTransformers.append(toggleVerseReference)
